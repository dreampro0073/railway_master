<?php 
urlencode(base64_encode($user->id))
$user_id = base64_decode($request->input("uid"));